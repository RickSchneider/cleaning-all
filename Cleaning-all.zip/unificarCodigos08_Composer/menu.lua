------- CLEANING ALL -------

local composer = require( "composer" )

local scene = composer.newScene()

-- -----------------------------------------------------------------------------------
-- Code outside of the scene event functions below will only be executed ONCE unless
-- the scene is removed entirely (not recycled) via "composer.removeScene()"
-- -----------------------------------------------------------------------------------

local function gotoGame()
	composer.gotoScene ("game", {time=800, effect="crossFade"})
end

local function gotoRecordes ()
	composer.gotoScene ("recordes", {time=800, effect="crossFade"})
end

 local musicaFundo 

-- -----------------------------------------------------------------------------------
-- Scene event functions
-- -----------------------------------------------------------------------------------

-- create()
function scene:create( event )

	local sceneGroup = self.view
	-- É executado quando a cena é aberta pela primeira vez, mas ainda não aparece na tela.

	local menu = display.newImageRect ( "imagens/menu.png", 400, 480)
    menu.x = display.contentCenterX
    menu.y = display.contentCenterY

    local titulo = display.newImageRect ( "imagens/titulo.png", 600/2, 360/2)
    titulo.x = -300
    titulo.y = 80
    transition.to (titulo, {time=1500, x= display.contentCenterX,  iterations=1})

    local subtitulo = display.newImageRect ( "imagens/subtitulo.png", 600/2, 360/2)
    subtitulo.x = 500
    subtitulo.y = 140
    transition.to (subtitulo, {time=1500, x= display.contentCenterX + 10,  iterations=1})

    local botaoPlay = display.newImageRect ( "imagens/play.png", 600/4.5, 360/4.5)
    botaoPlay.alpha = 0
    botaoPlay.x = display.contentCenterX
    botaoPlay.y = 240
    transition.to (botaoPlay, {alpha = 1, time = 2000})

    local creditos = display.newImageRect ("imagens/creditos.png", 350, 160)
    creditos.x = display.contentCenterX
    creditos.y = 460

	local botaoRecordes = display.newText (sceneGroup, "Recordes", display.contentCenterX, 400, Arial, 30)
	botaoRecordes:setFillColor (0.75, 0.78, 1)

	-- musicaFundo = audio.loadStream ("audio/Escape_Looping.wav")

	botaoPlay:addEventListener ("tap", gotoGame)
	botaoRecordes:addEventListener ("tap", gotoRecordes)

end


-- show()
function scene:show( event )

	local sceneGroup = self.view
	local phase = event.phase

	if ( phase == "will" ) then
		-- Acontece imediatamente antes da cena passar para tela.

	elseif ( phase == "did" ) then
		-- Acontece imediatamente após a cena estar ativa.
		audio.play (bgAudio, {channel=1,loops=-1})

	end
end


-- hide()
function scene:hide( event )

	local sceneGroup = self.view
	local phase = event.phase

	if ( phase == "will" ) then
		-- Imediatamente antes da cena sair da tela.

	elseif ( phase == "did" ) then
		-- Imediatamente após a cena sair da tela.
		audio.stop (1)

	end
end


-- destroy()
function scene:destroy( event )

	local sceneGroup = self.view
	-- Destruir informações do create que não estão relacionadas com os objetos de exibição.
	audio.dispose (bgAudio)

end


-- -----------------------------------------------------------------------------------
-- Scene event function listeners
-- -----------------------------------------------------------------------------------
scene:addEventListener( "create", scene )
scene:addEventListener( "show", scene )
scene:addEventListener( "hide", scene )
scene:addEventListener( "destroy", scene )
-- -----------------------------------------------------------------------------------

return scene
