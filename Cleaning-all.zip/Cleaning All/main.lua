------- CLEANING ALL -------

local composer = require ("composer")

audio.reserveChannels (1)
audio.setVolume (0.8, {channel=1})

math.randomseed (os.time ())

display.setStatusBar (display.HiddenStatusBar)
                
composer.gotoScene ("menu")

----------------------------------------



















 
      

       


