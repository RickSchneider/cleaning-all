
local composer = require( "composer" )

local scene = composer.newScene()

-- -----------------------------------------------------------------------------------
-- O código fora das funções de evento de cena abaixo será executado apenas UMA VEZ, a menos que
-- a cena é totalmente removida (não reciclada) via "composer.removeScene()"
-- -----------------------------------------------------------------------------------

local physics = require ("physics")
physics.start ()
physics.setGravity (0,0)
physics.setDrawMode ("normal")

local spriteOpcoes =
 { frames=
        {
        { -- 1) posição costas 1
                x = 0,
                y = 0,
                width = 46,
                height = 77 
        },
        { -- 2) posição costas  2
                x = 46,
                y = 0,
                width = 46,
                height = 77
        },
        { -- 3) posição costas  3
                x = 92,
                y = 0,
                width = 46,
                height =77 
        },
        { -- 4) posição costas 4
                x = 138,
                y = 0,
                width = 46,
                height =77 
        }, 
        { -- 5) posição costas 5 
                x = 184,
                y = 0,
                width = 46,
                height =77 
        },
        { -- 6) posição costas 6 
                x = 230,
                y = 0,
                width = 46,
                height =77 
        }, 
        { -- 7) posição costas 7
                x = 276,
                y = 0,
                width = 46,
                height =77 
        }, 
        { -- 8)  posição costas 8
                x = 322,
                y = 0,
                width = 46,
                height =77 
        }, 
        { -- 9) posição costas 9
                x = 368,
                y = 0,
                width = 46,
                height =77 
        },
        { -- 10) posição costas 10
                x = 414,
                y = 0,
                width = 46,
                height =77
        },
        { -- 11) posição costas 11 
                x = 0,
                y = 77,
                width = 46,
                height = 77 
        },
        { -- 12) posição CostasDireita  12
                x = 46,
                y = 77,
                width = 46,
                height = 77
        },
        { -- 13) posição CostasDireita 13
                x = 92,
                y = 77,
                width = 46,
                height =77 
        },
        { -- 14) posição CostasDireita 14
                x = 138,
                y = 77,
                width = 46,
                height =77 
        }, 
        { -- 15) posição CostasDireita 15 
                x = 184,
                y = 77,
                width = 46,
                height =77 
        },
         { -- 16) posição CostasDireita 16 
                x = 230,
                y = 77,
                width = 46,
                height =77 
        }, 
        { -- 17) posição CostasDireita 17
                x = 276,
                y = 77,
                width = 46,
                height =77 
        }, 
        { -- 18)  posição CostasDireita 18
                x = 322,
                y = 77,
                width = 46,
                height =77    }, 
        { -- 19) posição direita 19
                x = 368,
                y = 77,
                 width = 46,
                height =77 
        }, 
        { -- 20) posição direita 20
                x = 414,
                y = 77,
                width = 46,
                height =77},
        { -- 21) posição direita 21
                x = 0,
                y = 154,
                width = 46,
                height = 77 
        },
        { -- 22) posição direita  22
                x = 46,
                y = 154,
                width = 46,
                height = 77
        },
        { -- 23) posição direita 23
                x = 92,
                y = 154,
                width = 46,
                height =77 
        },
        { -- 24) posição direita 24
                x = 138,
                y = 154,
                width = 46,
                height =77 
        }, 
        { -- 25) posição direita 25 
                x = 184,
                y = 154,
                width = 46,
                height =77 
        },
         { -- 26) posição direita 26 
                x = 230,
                y = 154,
                width = 46,
                height =77 
        }, 
        { -- 27) posição direita 27
                x = 276,
                y = 154,
                width = 46,
                height =77 
        }, 
        { -- 28)  posição FrenteDireita 28
                x = 322,
                y = 154,
                width = 46,
                height =77 
        }, 
        { -- 29) posição FrenteDireita 29
                x = 368,
                y = 154,
                width = 46,
                height =77
        }, 
        { -- 30) posição FrenteDireita 30 
                x = 414,
                y = 154,
                width = 46,
                height =77},
        { -- 31) posição FrenteDireita 31
                x = 0,
                y = 231,
                width = 46,
                height = 77 
        },
        { -- 32) posição FrenteDireita  32
                x = 46,
                y = 231,
                width = 46,
                height = 77
        },
        { -- 33) posição FrenteDireita  33
                x = 92,
                y = 231,
                width = 46,
                height =77 
        },
        { -- 34) posição FrenteDireita 34
                x = 138,
                y = 231,
                width = 46,
                height =77 
        }, 
        { -- 35) posição FrenteDireita 35 
                x = 184,
                y = 231,
                width = 46,
                height =77 
        }, 
        { -- 36) posição FrenteDireita 36 
                x = 230,
                y = 231,
                width = 46,
                height =77 
        }, 
        { -- 37) posição frenteDireita 37
                x = 276,
                y = 231,
                width = 46,
                height =77 
        }, 
        { -- 38)  posição FrenteDireita 38
                x = 322,
                y = 231,
                width = 46,
                height =77 
        }, 
        { -- 39) posição FrenteDireita 39
                x = 368,
                y = 231,
                width = 46,
                height =77 
        }, 
        { -- 40) posição FrenteDireita 40 
                x = 414,
                y = 231,
                width = 46,
                height =77
        }, 
        { -- 41) posição FrenteDireita 41
                x = 0,
                y = 308,
                width = 46,
                height = 77 
        },
        { -- 42) posição FrenteDireita  42
                x = 46,
                y = 308,
                width = 46,
                height = 77
        },
        { -- 43) posição FrenteDireita  43
                x = 92,
                y = 308,
                width = 46,
                height =77 
        },
        { -- 44) posição FrenteDireita 44
                x = 138,
                y = 308,
                width = 46,
                height =77 
        }, 
        { -- 45) posição FrenteDireita 45 
                x = 184,
                y = 308,
                width = 46,
                height =77 
        },
        { -- 46) posição FrenteDireita 46 
                x = 230,
                y = 308,
                width = 46,
                height =77 
        }, 
        { -- 47) posição frente 47
                x = 276,
                y = 308,
                width = 46,
                height =77 
        }, 
        { -- 48)  posição frente 48
                x = 322,
                y = 308,
                width = 46,
                height =77 
        }, 
        { -- 49) posição frente 49
                x = 368,
                y = 308,
                width = 46,
                height =77 
        }, 
        { -- 50) posição frente 50
                x = 414,
                y = 308,
                width = 46,
                height =77
        },
        { -- 51) posição frente 51
                x = 0,
                y = 385,
                width = 46,
                height = 77 
        },
        { -- 52) posição frente  52
                x = 46,
                y = 385,
                width = 46,
                height = 77
        },
        { -- 53) posição frente  53
                x = 92,
                y = 385,
                width = 46,
                height =77 
        },
        { -- 54) posição sentado 54
                x = 138,
                y = 385,
                width = 46,
                height =77 
        }, 
        { -- 55) posição espada 55 
                x = 184,
                y = 385,
                width = 46,
                height =77 
        },
         { -- 56) posição espada 56 
                x = 230,
                y = 385,
                width = 46,
                height =77 
        }, 
        { -- 57) posição espada 57
                x = 276,
                y = 385,
                width = 46,
                height =77 
        }, 
        { -- 58)  posição espada 58
                x = 322,
                y = 385,
                width = 46,
                height =77 
        }, 
        { -- 59) posição espada 59
                x = 368,
                y = 385,
                width = 46,
                height =77 
        }, 
        { -- 60) posição espada 60 
                x = 414,
                y = 385,
                width = 46,
                height =77
        },
        { -- 61) posição espada 61
                x = 0,
                y = 462,
                width = 46,
                height = 77 
        },
        { -- 62) posição pegar  62
                x = 46,
                y = 462,
                width = 46,
                height = 77
        },
        { -- 63) posição pegar  63
                x = 92,
                y = 462,
                width = 46,
                height =77 
        }
        }
}

local spritePlayer = graphics.newImageSheet ("imagens/player.png", {width=46, height=77, numFrames=63})

local spriteAnimacao ={
                                        -- { nome, frameInicial, continuação, tempo, loopnis}
                                        {name="parado", start=44, count=1,time=1000, loopCount=0},
                                        {name="esquerda", start=18, count=4, time=1000, loopCount=0},
                                        {name="Costas", start=1, count=11, time=1000, loopCount=0},
                                        {name="costasDireita", start=12, count=7, time=1000, loopCount=0},
                                        {name="direita", start=19, count=8, time=1000, loopCount=0},
                                        {name="frente", start=28, count=18, time=1000, loopCount=0},
                                        {name="andando", start=37, count=5, time=1000, loopCount=0},
                                        {name="frentePlayer", star=56, count=8, time=1000,loopCount=0},
                                        {name="sentado", start=54, count=1, time=1000, loopCount=0},
                                        {name="espada", start=55, count=5, time=100, loopCount=2},
                                        {name="pegar", start=62, count=2, time=100, loopCount=0}

}

-- Inicializar variáveis
local vidas = 3
local moedas = 0
local morto = false

local player 
local carro 
local gameLoopTimer
local vidasText
local moedasText
local jornal

local bgAudio
local somMoeda

local backGroup  
local mainGroup 
local uiGroup 

local function proximaFase ()
        moedas = moedas 
        

end
local function resetPlayer()
    -- player.isBodyActive = false
    player.x = 200
    player.y = 450
    player.alpha = 1
    physics.addBody(player, "dynamic", {
        box = {
            x = 0,
            y = 0,
            halfWidth = 17,
            halfHeight = 27,
            angle = 0
        },
        isSensor = true
    })
end

local function moverDireita (event)
        if (event.phase == "began") then
                player.x = player.x +10
                player:setSequence ("andando") 
                player:play ()
              
        elseif (event.phase == "moved") then
                player.x = player.x +10

        elseif (event.phase == "ended") then
                player:setSequence ("parado")
                player:play ()
        end 
end

local function moverEsquerdo (event)
        if (event.phase == "began") then
                player.x = player.x -10
                player:setSequence ("esquerda") ---andando parza?
                player:play ()
                player.xScale = -1

        elseif (event.phase == "moved") then
                player.x = player.x -10

        elseif (event.phase == "ended") then
                player:setSequence ("parado")
                player:play ()
                player.xScale =-1
        end 
end 

 local function moverCima(event)
        if (event.phase == "began") then
                player.y = player.y -15
                player:setSequence ("Costas")
                player:play ()
          
        elseif (event.phase == "moved") then
                player.y = player.y -15

        elseif (event.phase == "ended") then
                player:setSequence ("parado")
                player:play ()
        end 
end 

 local function moverBaixo (event)
        if (event.phase == "began") then
                player.y = player.y +15
                player:setSequence ("andando") 
                player:play ()
                --player.xScale = 0.5

        elseif (event.phase == "moved") then
                player.y = player.y +15

        elseif (event.phase == "ended") then
                player:setSequence ("parado")
                player:play ()
                --player.xScale =0.5
        end 
end 

local timeTable = {5500,     4300,  2500,  2300,  2500,    1500,  900,  100, 3000, 100, 4500,  3100,
                   2500, 1500,   800, 500, 2000,3000,5000,2000, 1500, 1400,  1500, 500,  2500,  5000, 
                    3000,3500,2000,2500,1500,2500,  3500,2500,1100, 3000, 1100,1500, 2500, 3500, 3500,
                     2500,1500,2500,2000,1500,1500, 2500 ,  700,  1500,  2500,100,3500,1500,2500}

local TableX    = {220,         5,     5 ,    220,   220,     5,    5,  330,  330,  5,     5,  
                   220,  220,   5 ,    5,  220, 220,    5,   5,  5,  220, 220,      5,       5,   220, 
                    220,     5,   5,220,  220,  5 ,   5,  330,  330,   5,    5, 220,220,  
                     5,   5, 220, 220,  5,      5,   5,  220,220,     5,    5,   330,  330,220,220,  5,  5} 

local TableY    = {120,       110,    320,   320,     115,  115,  -30,  -20,  500, 500,  115,   115,
                   320,   320,  500,  500, 320,  320, -15,115,  115, 320,    320, 500,   500,  115,   
                   115, 320, 320,  115, 115, 500,  500,  -15, -15,  115, 115,320,   320,  500,  500, 115,115,  
                   -15,  320, 320,115,   115,   -15,  -15,  500,500,115,115, 500}
local i = 0

local function onComplete()
   i = i + 1
   if timeTable[i] then
      transition.to(carro, {
         time=timeTable[i], 
         x=TableX[i], 
         y=TableY[i], 
         onComplete=onComplete
      })
   end
end

-- Colisão Recicláveis

local function endGame ()
        composer.setVariable ("finalScore", pontos)
        composer.gotoScene ("menu", {time=800, effect="crossFade"})
end

local function recordes ()
        composer.setVariable ("finalScore", pontos)
        composer.gotoScene ("recordes", {time=800, effect="crossFade"})
end

local function onCollision (event)
        if (event.phase == "began") then
                local obj1 = event.object1
                local obj2 = event.object2
                if((obj1.myName == "jogador" and obj2.myName == "Lata")or
                        (obj1.myName == "Lata" and obj2.myName == "jogador"))
                then
                        print ("colidiu")
                        if (obj1.myName == "Lata")then
                                display.remove (obj1)
                        else
                                display.remove(obj2)
                                moedas = moedas + 100
                                moedasText.text = "Moedas: ".. moedas
                                audio.play (somMoeda)

                        end
                           
                        if (moedas > 300) then
                        transition.to (proximaFase, {time=1500, iterations=1})
                    
                                local proximaFase = display.newImageRect (uiGroup, "imagens/proximaFase.png" , 300, 180)
                                proximaFase.x = display.contentCenterX
                                proximaFase.y = display.contentCenterY

                        end
                
                elseif((obj1.myName == "jogador" and obj2.myName == "Caixa")or
                        (obj1.myName == "Caixa" and obj2.myName == "jogador"))
                then
                        print ("colidiu")
                        if (obj1.myName == "Caixa")then
                                display.remove (obj1)
                        else
                                display.remove(obj2)

                                moedas = moedas + 100
                                moedasText.text = "Moedas: ".. moedas
                                audio.play (somMoeda)
                        end

                        if (moedas > 300) then
                        transition.to (proximaFase, {time=1500, iterations=1})
                    
                                local proximaFase = display.newImageRect (uiGroup, "imagens/proximaFase.png" , 300, 180)
                                proximaFase.x = display.contentCenterX
                                proximaFase.y = display.contentCenterY
                        
                        end 

                elseif((obj1.myName == "jogador" and obj2.myName == "Coca")or
                                (obj1.myName == "Coca" and obj2.myName == "jogador"))
                then
                        if (obj1.myName == "Coca")then
                                display.remove (obj1)
                        else
                                display.remove(obj2)

                                moedas = moedas + 100
                                moedasText.text = "Moedas: ".. moedas
                                audio.play (somMoeda)
                        end
                
                        if (moedas > 300) then
                        transition.to (proximaFase, {time=1500, iterations=1})
                    
                                local proximaFase = display.newImageRect (uiGroup, "imagens/proximaFase.png" , 300, 180)
                                proximaFase.x = display.contentCenterX
                                proximaFase.y = display.contentCenterY

                        end
                
                elseif((obj1.myName == "jogador" and obj2.myName == "Garrafa")or
                                (obj1.myName == "Garrafa" and obj2.myName == "jogador"))
                then
                        if (obj1.myName == "Garrafa")then
                                display.remove (obj1)
                        else
                                display.remove(obj2)

                                moedas = moedas + 100
                                moedasText.text = "Moedas: ".. moedas
                                audio.play (somMoeda)
                        end

                        if (moedas > 300) then
                        transition.to (proximaFase, {time=1500, iterations=1})
                    
                                local proximaFase = display.newImageRect (uiGroup, "imagens/proximaFase.png" , 300, 180)
                                proximaFase.x = display.contentCenterX
                                proximaFase.y = display.contentCenterY

                        end
                                
                elseif((obj1.myName == "jogador" and obj2.myName == "Jornal")or
                        (obj1.myName == "Jornal" and obj2.myName == "jogador"))
                then
                        print ("colidiu")
                        if (obj1.myName == "Jornal")then
                                display.remove (obj1)
                        else
                                display.remove(obj2)

                                moedas = moedas + 100
                                moedasText.text = "Moedas: ".. moedas
                                audio.play (somMoeda)
                        end

                        if (moedas > 300) then
                        transition.to (proximaFase, {time=1500, iterations=1})
                    
                                local proximaFase = display.newImageRect (uiGroup, "imagens/proximaFase.png" , 300, 180)
                                proximaFase.x = display.contentCenterX
                                proximaFase.y = display.contentCenterY

                        end

                elseif((obj1.myName == "jogador" and obj2.myName == "Pet")or
                        (obj1.myName == "Pet" and obj2.myName == "jogador"))
                        
                then
                        if (obj1.myName == "Pet")then
                                display.remove (obj1)

                        else
                                display.remove(obj2)
                                
                                moedas = moedas + 100
                                moedasText.text = "Moedas: ".. moedas
                                audio.play (somMoeda)
                
                        end

                        if (moedas > 300) then
                        transition.to (proximaFase, {time=1500, iterations=1})
                    
                                local proximaFase = display.newImageRect (uiGroup, "imagens/proximaFase.png" , 300, 180)
                                proximaFase.x = display.contentCenterX
                                proximaFase.y = display.contentCenterY

                        end
-- Colisão Orgânicos 

                elseif((obj1.myName == "jogador" and obj2.myName == "Banana")or
                                (obj1.myName == "Banana" and obj2.myName == "jogador"))
                then
                        if (obj1.myName == "Banana")then
                                display.remove (obj1)
                        else
                                display.remove(obj2)
                                        moedas = moedas - 50
                                        moedasText.text = "Moedas: ".. moedas
                        end

                elseif((obj1.myName == "jogador" and obj2.myName == "Maca")or
                        (obj1.myName == "Maca" and obj2.myName == "jogador"))
                        then
                        if (obj1.myName == "Maca")then
                                display.remove (obj1)
                        else
                                display.remove(obj2)

                                moedas = moedas - 50
                                moedasText.text = "Moedas: ".. moedas
                        end
                        
-- Colisão Não Recicláveis e Tóxicos
                        
                elseif((obj1.myName == "jogador" and obj2.myName == "Seringa")or
                        (obj1.myName == "Seringa" and obj2.myName == "jogador"))
                then
                        if (obj1.myName == "Seringa")then
                                display.remove (obj1)
                        else
                                display.remove(obj2)

                                moedas = moedas - 100
                                moedasText.text = "Moedas: ".. moedas
                                
                        end
                                   
                elseif((obj1.myName == "jogador" and obj2.myName == "Fralda")or
                        (obj1.myName == "Fralda" and obj2.myName == "jogador"))
                then
                        if (obj1.myName == "Fralda")then
                                display.remove (obj1)
                        else
                                display.remove(obj2)

                                moedas = moedas - 100
                                moedasText.text = "Moedas: ".. moedas
                        end
                                  
                elseif((obj1.myName == "jogador" and obj2.myName == "Pilha")or
                        (obj1.myName == "Pilha" and obj2.myName == "jogador"))
                then
                        if (obj1.myName == "Pilha")then
                                display.remove (obj1)
                        else
                                display.remove(obj2)

                                moedas = moedas - 100
                                moedasText.text = "Moedas: ".. moedas
                        end
                                        
                elseif((obj1.myName == "jogador" and obj2.myName == "PapelHigienico")or
                        (obj1.myName == "PapelHigienico" and obj2.myName == "jogador"))
                then
                        if (obj1.myName == "PapelHigienico")then
                                display.remove (obj1)
                        else
                                display.remove(obj2)

                                moedas = moedas - 100
                                moedasText.text = "Moedas: ".. moedas
                        end
                                        
-- Colisão Carro

        elseif ((obj1.myName == "jogador" and obj2.myName == "carro") or
            (obj1.myName == "carro" and obj2.myName == "jogador")) then

            moedas = moedas - 300
            moedasText.text = "Moedas: " .. moedas

            vidas = vidas - 1
            vidasText.text = "Vidas: " .. vidas
            morto = false

                if (vidas == 0) then
                    display.remove(jogador)
                    timer.performWithDelay( 2000, endGame )

                    local gameOver = display.newImageRect(uiGroup, "imagens/gameOver.png", 280, 280)
                    gameOver.x = display.contentCenterX
                    gameOver.y = display.contentCenterY
                    
                else
                    player.alpha = 0
                    timer.performWithDelay(1000, resetPlayer)

                end -- if vidas
                end
        end          
end      

-- -----------------------------------------------------------------------------------
-- Scene event functions
-- -----------------------------------------------------------------------------------

-- create()
function scene:create( event ) -- parte gráfica (botões, imagens, áudio, textos, pausa da física, grupos...)

        local sceneGroup = self.view
        -- É executado quando a cena é aberta pela primeira vez, mas ainda não aparece na tela.

        physics.pause ()

        backGroup = display.newGroup ()
        sceneGroup:insert (backGroup)

        mainGroup = display.newGroup ()
        sceneGroup:insert (mainGroup)

        uiGroup = display.newGroup ()
        sceneGroup:insert (uiGroup)

        local bg = display.newImageRect (backGroup, "imagens/bg.png", 1080*0.35 , 1920*0.35)
        bg.x = display.contentCenterX
        bg.y = display.contentCenterY-50

        player = display.newSprite ( mainGroup, spritePlayer, spriteAnimacao)
        player.x = 250
        player.y = 450
        player:setSequence ("paradoFrente")
        player: play ()
        player.myName = "jogador"
        physics.addBody (player, "dynamic", {box= {x=0, y=0 , halfWidth=9, halfHeight=16, angle=0}})
        player.isFixedRotation = true

        local botaoDireito = display.newImageRect (uiGroup, "imagens/botao/botaoDireita.png", 180*0.15, 196*0.15)
        botaoDireito.x = 125
        botaoDireito.y = 415

        local botaoEsquerdo = display.newImageRect (uiGroup,"imagens/botao/botaoEsquerdo.png", 180*0.15, 196*0.15)
        botaoEsquerdo.x = 85
        botaoEsquerdo.y = 415

        local botaoCima = display.newImageRect (uiGroup, "imagens/botao/botaoCima.png", 180*0.15, 196*0.15)
        botaoCima.x = 104
        botaoCima.y = 390

        local botaoBaixo = display.newImageRect (uiGroup,"imagens/botao/botaoBaixo.png", 180*0.15, 196*0.15)
        botaoBaixo.x = 104
        botaoBaixo.y = 440

        carro = display.newImageRect ( mainGroup, "imagens/carro.gif", 25 , 25)
        carro.x = 220
        carro.y = 450
        physics.addBody (carro, "dynamic", {isSensor=true}) --radius?
        carro.myName="carro"

        --------------------Fisica sobre casas----------------------------------
        local retanguloSuperior =  display.newRect (mainGroup, 143, 47, 180, 28)
        retanguloSuperior.alpha=0
        physics.addBody (retanguloSuperior, "static")

        local retanguloLateral1 = display.newRect (mainGroup,275, 140, 40, 105)
        retanguloLateral1.alpha=0
        physics.addBody (retanguloLateral1, "static")

        local retanguloLateral2 = display.newRect (mainGroup,285, 260, 30, 90)
        retanguloLateral2.alpha=0
        physics.addBody (retanguloLateral2, "static")

        local retanguloLateral3 = display.newRect (mainGroup,275, 360, 40, 80)
        retanguloLateral3.alpha=0
        physics.addBody (retanguloLateral3, "static")

        local retanguloLateral4 = display.newRect (mainGroup,275, 455, 40, 80)
        retanguloLateral4.alpha=0
        physics.addBody (retanguloLateral4, "static")

        local quadradoCentro1 = display.newRect (mainGroup,138, 180, 100, 50)
        quadradoCentro1.alpha=0
        physics.addBody (quadradoCentro1, "static")

        local quadradoCentro2 = display.newRect (mainGroup,70, 235, 70, 45)
        quadradoCentro2.alpha=0
        physics.addBody (quadradoCentro2, "static")

        local quadradoCentro3 = display.newRect (mainGroup,150, 265, 70, 40)
        quadradoCentro3.alpha=0
        physics.addBody (quadradoCentro3, "static")

        local quadradoInferior = display.newRect ( mainGroup,109, 415, 120, 80)
        quadradoInferior.alpha=0
        physics.addBody (quadradoInferior, "static")

----------------------------------------------
        local caminhao = display.newImageRect (mainGroup, "imagens/caminhao.png", 500/9 , 500/8)
        caminhao.x = -6
        caminhao.y = 450
        caminhao.myname = "caminhao"
        transition.to (caminhao, {y=-10, x=-6 , time = 5500,
        onComplete = function () display.remove (caminhao)
        end}) 

-----------------------------------------------------
-- Recicláveis
        local lata = display.newImageRect (mainGroup, "imagens/lata.png", 170/6.5, 288/6.5 )
        lata.x = 130
        lata.y = 80
        lata.rotation = -15 
        physics.addBody(lata, "hybrid", { isSensor=true, radius = 15} )
        lata.myName = "Lata"

        local caixa = display.newImageRect (mainGroup, "imagens/caixa.png", 318/6, 270/6)
        caixa.x = 130
        caixa.y = 350
        physics.addBody(caixa, "kinematic", { isSensor=true, radius = 15} )
        caixa.myName = "Caixa"

        local coca = display.newImageRect (mainGroup, "imagens/coca.png", 282/6, 235/6)
        coca.x = 60
        coca.y = 15
        physics.addBody(coca,"kinematic", { isSensor=true, radius = 15} )
        coca.myName = "Coca"

        local garrafa = display.newImageRect (mainGroup, "imagens/garrafa.png", 214/6, 390/6)
        garrafa.x = 50
        garrafa.y = 170
        garrafa.rotation = 20
        physics.addBody(garrafa, "kinematic", { isSensor=true, radius = 15} )
        garrafa.myName = "Garrafa"

        jornal = display.newImageRect (mainGroup, "imagens/jornal.png", 40, 40)
        jornal.x = 40 
        jornal.y = 355 
        jornal.rotation = -40
        physics.addBody(jornal, "kinematic", { isSensor=true, radius = 15} )
        jornal.myName = "Jornal"

        local pet = display.newImageRect (mainGroup, "imagens/pet.png", 300/6.5, 300/6.5)
        pet.x = 250
        pet.y = 340
        physics.addBody(pet, "kinematic", { isSensor=true, radius = 15} )
        pet.myName = "Pet"

-- Orgânicos 

        local lixoBanana = display.newImageRect (mainGroup, "imagens/lixoOrganicoBanana.png", 45, 45)
        lixoBanana.x = 180
        lixoBanana.y = 290
        physics.addBody(lixoBanana, "kinematic", { isSensor=true, radius = 15} )
        lixoBanana.myName = "Banana"

        local lixoMaca = display.newImageRect (mainGroup, "imagens/lixoOrganicoMaca.png", 100/3.4, 100/3.4)
        lixoMaca.x = 200
        lixoMaca.y = 80
        physics.addBody(lixoMaca, "kinematic", { isSensor=true, radius = 15} )
        lixoMaca.myName = "Maca"

-- Não Recicláveis e Tóxicos

        local seringa = display.newImageRect (mainGroup, "imagens/seringa.png", 50, 50)
        seringa.x = 190
        seringa.y = 400
        physics.addBody(seringa, "kinematic", { isSensor=true, radius = 15} )
        seringa.myName = "Seringa"

        local lixoFralda = display.newImageRect (mainGroup, "imagens/naoreciclavel1.png", 282/7, 277/7)
        lixoFralda.x = 260
        lixoFralda.y = 210
        lixoFralda.rotation = -20
        physics.addBody(lixoFralda, "kinematic", { isSensor=true, radius = 15} )
        lixoFralda.myName = "Fralda"

        local pilha = display.newImageRect (mainGroup, "imagens/pilha.png", 40, 40)
        pilha.x = 70
        pilha.y = 280
        physics.addBody(pilha, "kinematic", { isSensor=true, radius = 15} )
        pilha.myName = "Pilha"

        local lixoPapelHigienico = display.newImageRect (mainGroup, "imagens/papelSujo.png", 50, 50)
        lixoPapelHigienico.x = 120
        lixoPapelHigienico.y = 150
        physics.addBody(lixoPapelHigienico, "kinematic", { isSensor=true, radius = 15} )
        lixoPapelHigienico.myName = "PapelHigienico"

        vidasText = display.newText (uiGroup, "Vidas: " .. vidas, 115, 25, Arial, 15)
        moedasText = display.newText (uiGroup, "Moedas: " .. moedas, 200, 25, Arial, 15)
        
        onComplete ()
        botaoDireito:addEventListener ("touch", moverDireita)
        botaoEsquerdo:addEventListener ("touch", moverEsquerdo)
        botaoCima:addEventListener ("touch", moverCima)
        botaoBaixo:addEventListener ("touch", moverBaixo)
        
        bgAudio = audio.loadStream ("audio/trilha.mp3")
        somMoeda = audio.loadSound ("audio/moeda.wav")

        audio.reserveChannels (1)
        audio.setVolume (0.01, {channel=1})
        audio.play (bgAudio, {channel=1, loops=-1})

end

-- show()
function scene:show( event )

        local sceneGroup = self.view
        local phase = event.phase

        if ( phase == "will" ) then
                -- Acontece imediatamente antes da cena passar para tela.

        elseif ( phase == "did" ) then
                -- Acontece imediatamente após a cena estar ativa.
        physics.start ()
        audio.play (bgAudio, {channel=1,loops=-1})
        Runtime:addEventListener ("collision", onCollision)
        end
end

-- hide()
function scene:hide( event )

        local sceneGroup = self.view
        local phase = event.phase

        if ( phase == "will" ) then
                -- Imediatamente antes da cena sair da tela.

        elseif ( phase == "did" ) then
                -- Imediatamente após a cena sair da tela.
        Runtime:addEventListener ("collision", onCollision)
        physics.pause ()
        audio.stop (1)
        composer.removeScene ("game")
        end
end

-- destroy()
function scene:destroy( event )

        local sceneGroup = self.view
        -- Destruir informações do create que não estão relacionadas com os objetos de exibição.
        audio.dispose (musicaFundo)
        audio.dispose (somMoeda)
end

-- -----------------------------------------------------------------------------------
-- Scene event function listeners
-- -----------------------------------------------------------------------------------
scene:addEventListener( "create", scene )
scene:addEventListener( "show", scene )
scene:addEventListener( "hide", scene )
scene:addEventListener( "destroy", scene )
-- -----------------------------------------------------------------------------------

return scene
