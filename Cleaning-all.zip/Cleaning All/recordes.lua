------- STAR EXPLORER -------
local composer = require( "composer" )

local scene = composer.newScene()

-- -----------------------------------------------------------------------------------
-- Code outside of the scene event functions below will only be executed ONCE unless
-- the scene is removed entirely (not recycled) via "composer.removeScene()"
-- -----------------------------------------------------------------------------------

local json = require ("json") -- Chama a biblioteca json

local pontosTable = {}

-- Cria o arquivo pontos.json e juntamente um caminho para a pasta
local filePath = system.pathForFile ("pontos.json", system.DocumentsDirectory)

local musicaFundo 

local function carregaPontos ()

	-- Abre o arquivo pontos.json como somente leitura
	local pasta = io.open (filePath, "r") 

	if pasta then
		local contents = pasta:read ("*a") -- Traz todos os dados do arquivo.
		io.close (pasta) 
		-- Decodificar as informações do arquivo e salva na table
		pontosText = json.decode (contents) 
	end
	if (pontosTable == nil or #pontosTable == 0) then -- # define TODOS os dados da tabela
		-- Define as pontuações iniciais dos recordes
		pontosTable = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0} 
	end
end	

local function salvaPontos ()
	for i = #pontosTable, 11, -1 do -- define que apenas 10 pontuações serão salvas.
		table.remove (pontosTable, i)
	end

	local pasta = io.open (filePath, "w") -- abre o arquivo para alterações.

	if pasta then
		-- Inclui as informações da variável table codificada para json.
		pasta:write (json.encode (pontosTable))
		io.close (pasta)
	end
end

local function gotoMenu ()
	composer.gotoScene ("menu", {time=800, effect="crossFade"})
end



-- -----------------------------------------------------------------------------------
-- Scene event functions
-- -----------------------------------------------------------------------------------

-- create()
function scene:create( event )

	local sceneGroup = self.view
	-- É executado quando a cena é aberta pela primeira vez, mas ainda não aparece na tela.
	carregaPontos () -- executa a função que puxa as pontuações anteriores.

	-- inclui a pontuação salva do último jogo na mesa.
	table.insert (pontosTable, composer.getVariable ("finalScore"))

	-- redefine o valor da variável.
	composer.setVariable ("finalScore" , 0)

	-- função de organização dos valores da tabela do maior para o menor.
	local function compare (a, b)
		return a > b 
	end 
	table.sort( pontosTable, compare ) -- Classifica a ordem definida em compare para a table

	salvaPontos () -- Salva os dados atualizados no arquivo json

	local bgRecordes = display.newImageRect (sceneGroup, "imagens/recordes.png", 529, 670)
	bgRecordes.x, bgRecordes.y = display.contentCenterX, display.contentCenterY
	bgRecordes.alpha = 0.5

	local cabecalho = display.newText (sceneGroup, "Recordes", display.contentCenterX, 40, Arial, 24)
	cabecalho:setFillColor (0.75, 0.78,1)

-- Cria um loop de 1 a 10 para exibir as pontuações
	for i = 1, 10 do
		-- Atribui os valores da pontosTable como os que aparecem no loop.
		if (pontosTable[i]) then
		-- Define que o espaçamento das pontuações seja uniforme de acordp com o número.
			local yPos = 25 + (i*36)

			local ranking = display.newText (sceneGroup, i .. ")", display.contentCenterX-10, yPos+22, Arial, 20)
			ranking:setFillColor (0.8)
		-- alinha o texto à direita alterando a âncora.
			ranking.anchorX = 1

			local finalPontos = display.newText (sceneGroup, pontosTable[i], display.contentCenterX, yPos+22, Arial, 20)
		-- Alinha o terxto à esquerda
			finalPontos.anchorX = 0
		end
	end

		local botaoMenu = display.newText (sceneGroup, "Menu", display.contentCenterX, 450, Arial, 24)
		botaoMenu:setFillColor (0.75, 0.78, 1)
		botaoMenu:addEventListener ("tap", gotoMenu)

		musicaFundo = audio.loadStream ("audio/Midnight-Crawlers_Looping.wav")
end


-- show()
function scene:show( event )

	local sceneGroup = self.view
	local phase = event.phase

	if ( phase == "will" ) then
		-- Acontece imediatamente antes da cena passar para tela.

	elseif ( phase == "did" ) then
		-- Acontece imediatamente após a cena estar ativa.
		audio.play (musicaFundo, {channel=1, loops=-1})

	end
end


-- hide()
function scene:hide( event )

	local sceneGroup = self.view
	local phase = event.phase

	if ( phase == "will" ) then
		-- Imediatamente antes da cena sair da tela.

	elseif ( phase == "did" ) then
		-- Imediatamente após a cena sair da tela.
		audio.stop (1)
		composer.removeScene ("recordes")
	end
end


-- destroy()
function scene:destroy( event )

	local sceneGroup = self.view
	-- Destruir informações do create que não estão relacionadas com os objetos de exibição.
	audio.dispose (musicaFundo)
end


-- -----------------------------------------------------------------------------------
-- Scene event function listeners
-- -----------------------------------------------------------------------------------
scene:addEventListener( "create", scene )
scene:addEventListener( "show", scene )
scene:addEventListener( "hide", scene )
scene:addEventListener( "destroy", scene )
-- -----------------------------------------------------------------------------------

return scene
